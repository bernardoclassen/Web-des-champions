Pour ce travail, on a créé une base de données interactive. Il est chargé de rechercher les données de plusieurs pays sur le site Wikipédia. De là, on retire les informations sous forme de texte et on les traite pour les stocker correctement. Ce fichier a été créé en langage python et s'appelle "Base. donnes.py".

Pour faciliter notre travail de création d'une plate-forme numérique, on utilisera une base de données faite à la main pour mieux configurer le site. En effet, lors de la recherche de certains noms de pays ou de leurs capitales, les lettres n'étaient pas toujours en majuscules. Il s'agit de la base de données "base_de_donnee.sqlite" créée. 

